      #include <sys/types.h>
      #include <sys/stat.h>
      #include <fcntl.h>
      #include <stdio.h>
      #include <memory.h>
      #include <iostream>
      #include <termios.h>     

      int openOmnimaLCDComms(const char* ttyDev)
      {
	  struct termios newtio;

          int fd = open(ttyDev, O_RDWR);
	  if (fd <0) perror(ttyDev);

	  tcgetattr (fd,&newtio);    // get the current port settings
	  newtio.c_cflag = B19200 | CS8 | CLOCAL | CREAD;
	  newtio.c_iflag = IGNPAR;
	  newtio.c_oflag = 0;
	  newtio.c_lflag = ICANON; 
          newtio.c_cc[VEOL] = 0;
	  tcflush(fd, TCIFLUSH);
	  tcsetattr(fd,TCSANOW, &newtio);
          tcflush(fd, TCIFLUSH);
          return fd;
      }

      void WriteToLCD(int fd, const char *str)
      {
          int i = strlen(str);
          write(fd, str, i);
          if (i>0 && str[i-1]!='\r') write(fd, "\r", 1);
      }
        
      main()
      {
        int fd,c, res;

	fd=openOmnimaLCDComms("/dev/ttyUSB0");
	WriteToLCD(fd,"#@Text MW Hor 50 140 Hello Wenjun!");
	close(fd);
      }
