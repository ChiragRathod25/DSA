#include <windows.h> 
#include <gl\glut.h> 
extern void draw_SnowMan(GLfloat *snomanXforms, GLfloat *botXforms, GLfloat *tumXforms, GLfloat *headXforms,
						 GLfloat *lXforms, GLfloat *rXforms, GLfloat *noseXforms, GLfloat *lHandXforms, GLfloat *rHandXforms);