#include <windows.h> 
#include <gl\glut.h> 

#ifndef _SNOWMAN_H
#define _SNOWMAN_H


extern void draw_SnowMan(GLfloat *snomanXforms, GLfloat *botXforms, GLfloat *tumXforms, GLfloat *headXforms,
						 GLfloat *lXforms, GLfloat *rXforms, GLfloat *noseXforms, GLfloat *lHandXforms, GLfloat *rHandXforms);


#endif