
extern GLfloat LinearValue(GLfloat KFInitValue, GLfloat KFFinalValue, int N, int f);
extern GLfloat EvaluateLinearAt(GLfloat *KeyFrameValues, GLint *KeyFramePositions, GLint NumOfKeyFrames, GLint f);
